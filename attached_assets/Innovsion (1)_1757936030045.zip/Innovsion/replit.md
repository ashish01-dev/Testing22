# EduPath - Educational Guidance Platform

## Overview

EduPath is a comprehensive educational guidance platform designed to help students make informed decisions about their academic and career paths. The application provides personalized career recommendations through aptitude quizzes, college search functionality, timeline tracking for important deadlines, and detailed career path mappings. Built as a full-stack web application, it serves as a one-stop solution for students navigating educational choices in India.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **Component Structure**: Modular component architecture with reusable UI components

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Development Setup**: Hot module replacement via Vite integration
- **Error Handling**: Centralized error middleware with structured error responses
- **Request Logging**: Custom middleware for API request/response logging

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Management**: Type-safe database schemas with Zod validation
- **Connection**: Neon serverless PostgreSQL for cloud deployment
- **Migrations**: Drizzle-kit for database schema migrations
- **Development Storage**: In-memory storage implementation for development/testing

### Key Data Models
- **Users**: Authentication and profile management
- **Quiz Results**: Aptitude test responses and career recommendations
- **Colleges**: Educational institution data with location and stream filtering
- **Timelines**: Important dates for admissions, exams, and scholarships
- **Saved Items**: User bookmarks for colleges, careers, and timelines

### Authentication and Authorization
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **User Profiles**: JSON-based profile storage with flexible schema
- **Route Protection**: Middleware-based access control for protected endpoints

### Application Features
- **Career Assessment**: Multi-category quiz system with personality and interest evaluation
- **College Discovery**: Location and stream-based college search with detailed information
- **Timeline Management**: Deadline tracking for educational milestones
- **Career Mapping**: Course-to-career pathway visualization
- **User Profiles**: Personalized dashboards with recommendations and saved items

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless driver for database connectivity
- **drizzle-orm**: Type-safe ORM for database operations and queries
- **express**: Web application framework for API development
- **@tanstack/react-query**: Data fetching and caching for React applications

### UI and Styling
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library for consistent iconography

### Development Tools
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for Node.js
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **@replit/vite-plugin-cartographer**: Replit-specific development features

### Form and Validation
- **react-hook-form**: Form state management and validation
- **@hookform/resolvers**: Validation resolvers for react-hook-form
- **zod**: TypeScript-first schema validation library
- **drizzle-zod**: Integration between Drizzle ORM and Zod validation

### Additional Libraries
- **date-fns**: Date manipulation and formatting utilities
- **wouter**: Lightweight client-side routing
- **cmdk**: Command palette and search functionality
- **embla-carousel-react**: Carousel component for interactive content