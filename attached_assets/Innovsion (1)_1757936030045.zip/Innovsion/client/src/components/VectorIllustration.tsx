import { Plane, Building2, Stethoscope, Wrench } from "lucide-react";

interface VectorIllustrationProps {
  className?: string;
}

export default function VectorIllustration({ className = "" }: VectorIllustrationProps) {
  return (
    <div className={`relative hero-illustration ${className}`}>
      <div className="relative w-full h-96 lg:h-[500px]">
        {/* Main illustration container with students in professional attire */}
        
        {/* Student in doctor suit - represented by medical themed illustration */}
        <div className="absolute top-0 left-0 w-64 h-64 bg-gradient-to-br from-blue-100 to-blue-200 rounded-full shadow-xl border-4 border-white flex items-center justify-center">
          <div className="text-center">
            <Stethoscope className="w-16 h-16 text-blue-600 mx-auto mb-2" />
            <div className="text-sm font-semibold text-blue-800">Medical Professional</div>
          </div>
        </div>
        
        {/* Engineer illustration - professional with confident posture */}
        <div className="absolute bottom-0 right-0 w-48 h-48 bg-gradient-to-br from-green-100 to-green-200 rounded-2xl shadow-lg flex items-center justify-center">
          <div className="text-center">
            <Wrench className="w-12 h-12 text-green-600 mx-auto mb-2" />
            <div className="text-sm font-semibold text-green-800">Engineer</div>
            <div className="text-xs text-green-600">Confident Stance</div>
          </div>
        </div>
        
        {/* Airplane and tower illustration */}
        <div className="absolute top-1/2 right-1/4 w-56 h-32 bg-gradient-to-r from-orange-100 to-orange-200 rounded-xl shadow-md flex items-center justify-center">
          <div className="flex items-center space-x-4">
            <Plane className="w-8 h-8 text-orange-600" />
            <Building2 className="w-10 h-10 text-orange-700" />
          </div>
        </div>
        
        {/* Decorative floating elements */}
        <div className="absolute top-1/4 left-1/2 w-4 h-4 bg-accent rounded-full pulse-animation"></div>
        <div className="absolute bottom-1/3 left-1/4 w-6 h-6 bg-orange-400 rounded-full pulse-animation" style={{ animationDelay: "1s" }}></div>
        <div className="absolute top-3/4 right-1/3 w-3 h-3 bg-green-400 rounded-full pulse-animation" style={{ animationDelay: "2s" }}></div>
        
        {/* Additional decorative elements */}
        <div className="absolute top-1/3 left-1/3 w-8 h-8 bg-purple-200 rounded-lg shadow-sm flex items-center justify-center">
          <div className="w-4 h-4 bg-purple-500 rounded-full"></div>
        </div>
        
        {/* Career symbols floating around */}
        <div className="absolute top-2/3 left-1/5 w-12 h-12 bg-pink-100 rounded-full shadow-md flex items-center justify-center">
          <div className="text-pink-600 text-xs font-bold">📚</div>
        </div>
        
        <div className="absolute top-1/5 right-1/5 w-10 h-10 bg-cyan-100 rounded-lg shadow-sm flex items-center justify-center">
          <div className="text-cyan-600 text-xs font-bold">🎓</div>
        </div>
      </div>
    </div>
  );
}
