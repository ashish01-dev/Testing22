import { useLocation } from "wouter";
import { GraduationCap, Brain, Route, MapPin, Calendar, User, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState, useEffect } from "react";
import innovisionLogo from "../assets/innovision-logo.png";

const navigationItems = [
  { href: "/", label: "Home", icon: GraduationCap },
  { href: "/quiz", label: "Quiz", icon: Brain },
  { href: "/careers", label: "Careers", icon: Route },
  { href: "/colleges", label: "Colleges", icon: MapPin },
  { href: "/timeline", label: "Timeline", icon: Calendar },
  { href: "/profile", label: "Profile", icon: User },
];

export default function FloatingNavigation() {
  const [location, setLocation] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const floatingNavStyle = {
    background: isScrolled ? "rgba(255, 255, 255, 0.15)" : "rgba(255, 255, 255, 0.1)",
  };

  return (
    <nav 
      className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50 floating-nav rounded-full px-8 py-4 shadow-xl transition-all duration-300"
      style={floatingNavStyle}
      data-testid="floating-navigation"
    >
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <img 
            src={innovisionLogo} 
            alt="Innovision Logo" 
            className="w-8 h-8 rounded-full"
          />
          <span className="font-bold text-lg text-primary">Innovision</span>
        </div>
        
        <div className="hidden md:flex items-center space-x-6">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.href}
                onClick={() => setLocation(item.href)}
                className={`font-medium transition-colors duration-200 flex items-center space-x-1 ${
                  location === item.href 
                    ? "text-primary" 
                    : "text-foreground hover:text-primary"
                }`}
                data-testid={`nav-${item.label.toLowerCase()}`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden" data-testid="mobile-menu-trigger">
              <Menu className="h-5 w-5 text-primary" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-64">
            <div className="flex flex-col space-y-4 mt-8">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.href}
                    onClick={() => setLocation(item.href)}
                    className={`flex items-center space-x-3 p-3 rounded-lg transition-colors duration-200 ${
                      location === item.href 
                        ? "bg-primary text-primary-foreground" 
                        : "hover:bg-muted"
                    }`}
                    data-testid={`mobile-nav-${item.label.toLowerCase()}`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
}
