import { useState, useCallback, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { MapPin, Search, Star, Users, BookOpen, Wifi, Car, Phone, Mail, Globe, Award, Building } from "lucide-react";
import type { College } from "@shared/schema";

// Custom debounce hook
function useDebounce(callback: Function, delay: number) {
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  return useCallback((...args: any[]) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    timeoutRef.current = setTimeout(() => callback(...args), delay);
  }, [callback, delay]);
}

export default function Colleges() {
  const [searchLocation, setSearchLocation] = useState("");
  const [selectedStream, setSelectedStream] = useState<string>("all");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [selectedCollege, setSelectedCollege] = useState<College | null>(null);
  const [showCollegeModal, setShowCollegeModal] = useState(false);
  
  // Applied filters (only these trigger the API call)
  const [appliedLocation, setAppliedLocation] = useState("");
  const [appliedStream, setAppliedStream] = useState<string>("all");
  const [appliedType, setAppliedType] = useState<string>("all");

  const { data: colleges, isLoading, refetch } = useQuery<College[]>({
    queryKey: ["/api/colleges", appliedLocation, appliedStream, appliedType],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (appliedLocation) params.append("location", appliedLocation);
      if (appliedStream && appliedStream !== "all") params.append("stream", appliedStream);
      if (appliedType && appliedType !== "all") params.append("type", appliedType);
      
      const response = await fetch(`/api/colleges?${params}`);
      if (!response.ok) throw new Error("Failed to fetch colleges");
      return response.json();
    },
  });

  // Remove client-side filtering since it's now handled server-side
  const filteredColleges = colleges || [];

  const handleSearch = useCallback(() => {
    // Apply current filter values and trigger API call
    setAppliedLocation(searchLocation);
    setAppliedStream(selectedStream);
    setAppliedType(selectedType);
  }, [searchLocation, selectedStream, selectedType]);
  
  // Debounced search for location input
  const debouncedLocationSearch = useDebounce((location: string) => {
    setAppliedLocation(location);
  }, 500);
  
  const handleLocationChange = (value: string) => {
    setSearchLocation(value);
    if (value.length >= 3 || value === "") {
      debouncedLocationSearch(value);
    }
  };
  
  const handleClearFilters = () => {
    setSearchLocation("");
    setSelectedStream("all");
    setSelectedType("all");
    setAppliedLocation("");
    setAppliedStream("all");
    setAppliedType("all");
  };
  
  // Auto-apply stream and type filters when changed
  useEffect(() => {
    setAppliedStream(selectedStream);
  }, [selectedStream]);
  
  useEffect(() => {
    setAppliedType(selectedType);
  }, [selectedType]);

  const getFacilityIcon = (facility: string) => {
    switch (facility.toLowerCase()) {
      case 'wifi':
      case 'internet':
        return <Wifi className="h-4 w-4" />;
      case 'hostel':
      case 'accommodation':
        return <Users className="h-4 w-4" />;
      case 'library':
        return <BookOpen className="h-4 w-4" />;
      case 'parking':
      case 'transport':
        return <Car className="h-4 w-4" />;
      default:
        return <Star className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 pt-20">
      <div className="container mx-auto px-6 py-12">
        <div className="text-center mb-16">
          <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <MapPin className="text-white text-2xl" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Government Colleges Directory</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover quality education opportunities near you with detailed information and requirements
          </p>
        </div>

        {/* Search and Filter Bar */}
        <Card className="mb-12 shadow-lg">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-5 gap-4">
              <div className="relative md:col-span-2">
                <MapPin className="absolute left-3 top-4 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Enter your location (min 3 chars)"
                  value={searchLocation}
                  onChange={(e) => handleLocationChange(e.target.value)}
                  className="pl-10"
                  data-testid="input-location"
                />
              </div>
              
              <Select value={selectedStream} onValueChange={setSelectedStream}>
                <SelectTrigger data-testid="select-stream">
                  <SelectValue placeholder="All Streams" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Streams</SelectItem>
                  <SelectItem value="Engineering">Engineering</SelectItem>
                  <SelectItem value="Medical">Medical</SelectItem>
                  <SelectItem value="Commerce">Commerce</SelectItem>
                  <SelectItem value="Arts">Arts</SelectItem>
                  <SelectItem value="Science">Science</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger data-testid="select-type">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="government">Government</SelectItem>
                  <SelectItem value="private">Private</SelectItem>
                  <SelectItem value="government-aided">Government Aided</SelectItem>
                </SelectContent>
              </Select>

              <Button 
                onClick={handleSearch}
                className="w-full"
                data-testid="button-search-colleges"
              >
                <Search className="mr-2 h-4 w-4" />
                Search
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-4"></div>
                  <div className="flex gap-2 mb-4">
                    <div className="h-6 w-16 bg-gray-200 rounded"></div>
                    <div className="h-6 w-16 bg-gray-200 rounded"></div>
                  </div>
                  <div className="h-10 bg-gray-200 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold">
                {filteredColleges.length} College{filteredColleges.length !== 1 ? 's' : ''} Found
              </h2>
              <div className="text-sm text-muted-foreground">
                {appliedLocation && `Near "${appliedLocation}"`}
                {appliedStream && appliedStream !== "all" && ` • ${appliedStream} Stream`}
                {appliedType && appliedType !== "all" && ` • ${appliedType.charAt(0).toUpperCase() + appliedType.slice(1)} Colleges`}
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredColleges.map((college) => (
                <Card 
                  key={college.id} 
                  className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer"
                  data-testid={`card-college-${college.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <div className="h-48 bg-gradient-to-br from-blue-100 to-blue-200 rounded-t-lg flex items-center justify-center">
                    <div className="text-center p-4">
                      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-2">
                        <Users className="h-8 w-8 text-blue-600" />
                      </div>
                      <div className="text-blue-800 font-semibold">Government College</div>
                    </div>
                  </div>
                  
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-bold line-clamp-1">{college.name}</h3>
                      {college.type === 'government' && (
                        <Badge className="bg-green-100 text-green-800 text-xs">
                          Government
                        </Badge>
                      )}
                    </div>
                    
                    <p className="text-muted-foreground text-sm mb-4 flex items-center">
                      <MapPin className="h-3 w-3 mr-1" />
                      {college.location}, {college.state}
                    </p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {Array.isArray(college.streams) ? college.streams.slice(0, 3).map((stream: string) => (
                        <Badge key={stream} variant="outline" className="text-xs">
                          {stream}
                        </Badge>
                      )) : null}
                      {Array.isArray(college.streams) && college.streams.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{college.streams.length - 3} more
                        </Badge>
                      )}
                    </div>

                    {college.facilities && Array.isArray(college.facilities) && (college.facilities as string[]).length > 0 && (
                      <div className="flex flex-wrap gap-2 mb-4">
                        {(college.facilities as string[]).slice(0, 3).map((facility: string) => (
                          <div 
                            key={facility} 
                            className="flex items-center space-x-1 text-xs text-muted-foreground bg-gray-100 px-2 py-1 rounded"
                          >
                            {getFacilityIcon(facility)}
                            <span>{String(facility)}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    <Button 
                      className="w-full"
                      onClick={() => {
                        setSelectedCollege(college);
                        setShowCollegeModal(true);
                      }}
                      data-testid={`button-view-details-${college.name.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      View Details
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredColleges.length === 0 && (
              <Card className="text-center p-12">
                <CardContent>
                  <MapPin className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No colleges found</h3>
                  <p className="text-muted-foreground mb-4">
                    Try adjusting your search criteria or location to find more colleges.
                  </p>
                  <Button variant="outline" onClick={handleClearFilters}>
                    Clear Filters
                  </Button>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* College Details Modal */}
        <Dialog open={showCollegeModal} onOpenChange={setShowCollegeModal}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold">
                {selectedCollege?.name}
              </DialogTitle>
              <DialogDescription className="flex items-center text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mr-1" />
                {selectedCollege?.location}, {selectedCollege?.state}
              </DialogDescription>
            </DialogHeader>

            {selectedCollege && (
              <div className="space-y-6">
                {/* College Type & Ranking */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Badge className={selectedCollege.type === 'government' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}>
                      {String(selectedCollege.type === 'government' ? 'Government' : 'Private')}
                    </Badge>
                    <Badge variant="outline">
                      <Award className="h-3 w-3 mr-1" />
                      NIRF Ranked
                    </Badge>
                  </div>
                </div>

                {/* Streams Offered */}
                <div>
                  <h3 className="font-semibold mb-3 flex items-center">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Streams Offered
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {Array.isArray(selectedCollege.streams) && (selectedCollege.streams as string[]).map((stream: string) => (
                      <Badge key={stream} variant="secondary">
                        {stream}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Facilities */}
                {selectedCollege.facilities && Array.isArray(selectedCollege.facilities) && (
                  <div>
                    <h3 className="font-semibold mb-3 flex items-center">
                      <Building className="h-4 w-4 mr-2" />
                      Facilities
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {(selectedCollege.facilities as string[]).map((facility: string) => (
                        <div key={facility} className="flex items-center space-x-2 text-sm bg-gray-50 p-2 rounded">
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          <span>{String(facility)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Cutoffs */}
                {selectedCollege.cutoffs && typeof selectedCollege.cutoffs === 'object' && 'general' in selectedCollege.cutoffs && (
                  <div>
                    <h3 className="font-semibold mb-3">
                      Admission Cutoffs ({selectedCollege.type === 'government' || selectedCollege.type === 'government-aided' ? 'JEE Main Rank' : 'Merit Percentile'})
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded">
                        <div className="text-sm text-muted-foreground">General</div>
                        <div className="text-lg font-bold text-blue-600">
                          {selectedCollege.type === 'government' || selectedCollege.type === 'government-aided' 
                            ? `Rank ${(selectedCollege.cutoffs as any).general}` 
                            : `${(selectedCollege.cutoffs as any).general}%`}
                        </div>
                      </div>
                      <div className="text-center p-3 bg-green-50 rounded">
                        <div className="text-sm text-muted-foreground">OBC</div>
                        <div className="text-lg font-bold text-green-600">
                          {selectedCollege.type === 'government' || selectedCollege.type === 'government-aided' 
                            ? `Rank ${(selectedCollege.cutoffs as any).obc}` 
                            : `${(selectedCollege.cutoffs as any).obc}%`}
                        </div>
                      </div>
                      <div className="text-center p-3 bg-orange-50 rounded">
                        <div className="text-sm text-muted-foreground">SC</div>
                        <div className="text-lg font-bold text-orange-600">
                          {selectedCollege.type === 'government' || selectedCollege.type === 'government-aided' 
                            ? `Rank ${(selectedCollege.cutoffs as any).sc}` 
                            : `${(selectedCollege.cutoffs as any).sc}%`}
                        </div>
                      </div>
                      <div className="text-center p-3 bg-purple-50 rounded">
                        <div className="text-sm text-muted-foreground">ST</div>
                        <div className="text-lg font-bold text-purple-600">
                          {selectedCollege.type === 'government' || selectedCollege.type === 'government-aided' 
                            ? `Rank ${(selectedCollege.cutoffs as any).st}` 
                            : `${(selectedCollege.cutoffs as any).st}%`}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Additional Information */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold mb-3">Admission Process</h3>
                    <div className="space-y-2 text-sm text-muted-foreground">
                      <p>• {selectedCollege.type === 'government' ? 'JEE Main + JoSAA Counselling' : 'JEE Main / Institution Entrance'}</p>
                      <p>• Online Application Process</p>
                      <p>• Document Verification Required</p>
                      <p>• Seat Allotment Based on Merit</p>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold mb-3">Contact Information</h3>
                    <div className="space-y-2 text-sm text-muted-foreground">
                      <div className="flex items-center">
                        <Phone className="h-4 w-4 mr-2" />
                        <span>+91-XX-XXXX-XXXX</span>
                      </div>
                      <div className="flex items-center">
                        <Mail className="h-4 w-4 mr-2" />
                        <span>admissions@{selectedCollege.name.toLowerCase().replace(/\s+/g, '')}.edu.in</span>
                      </div>
                      <div className="flex items-center">
                        <Globe className="h-4 w-4 mr-2" />
                        <span>www.{selectedCollege.name.toLowerCase().replace(/\s+/g, '')}.edu.in</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4 border-t">
                  <Button className="flex-1" data-testid="button-apply-now">
                    Apply Now
                  </Button>
                  <Button variant="outline" className="flex-1" data-testid="button-save-college">
                    Save to Profile
                  </Button>
                  <Button variant="outline" data-testid="button-compare">
                    Compare
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
