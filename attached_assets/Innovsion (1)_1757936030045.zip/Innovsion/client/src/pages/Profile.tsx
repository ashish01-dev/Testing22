import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { 
  User, 
  Edit, 
  Bell, 
  Settings, 
  BookOpen, 
  MapPin, 
  Route, 
  Star,
  CheckCircle,
  TrendingUp,
  Calendar,
  Bookmark,
  Eye,
  EyeOff,
  Volume2,
  VolumeX
} from "lucide-react";

interface UserProfile {
  name: string;
  age: string;
  gender: string;
  class: string;
  interests: string[];
  location: string;
}

interface RecommendationItem {
  id: string;
  title: string;
  type: 'course' | 'college' | 'career';
  description: string;
  match: number;
  saved: boolean;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  progress: number;
}

export default function Profile() {
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: "Priya Sharma",
    age: "17",
    gender: "Female",
    class: "12th Science",
    interests: ["Mathematics", "Physics", "Research"],
    location: "Delhi"
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState(userProfile);
  const [visibleElements, setVisibleElements] = useState<Set<string>>(new Set());
  
  // Settings state
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [smsAlerts, setSmsAlerts] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [language, setLanguage] = useState("English");

  const recommendations: RecommendationItem[] = [
    {
      id: "1",
      title: "B.Tech Computer Science",
      type: "course",
      description: "Perfect match based on your math and analytical skills",
      match: 95,
      saved: true
    },
    {
      id: "2", 
      title: "IIT Delhi",
      type: "college",
      description: "Top engineering college, 8.7 km from your location",
      match: 88,
      saved: false
    },
    {
      id: "3",
      title: "Software Engineer",
      type: "career", 
      description: "High demand career with excellent growth prospects",
      match: 92,
      saved: true
    },
    {
      id: "4",
      title: "Data Scientist",
      type: "career",
      description: "Emerging field combining math, programming, and analytics",
      match: 87,
      saved: false
    },
    {
      id: "5",
      title: "Delhi Technological University",
      type: "college",
      description: "Government engineering college with excellent placement record",
      match: 85,
      saved: true
    }
  ];

  const achievements: Achievement[] = [
    {
      id: "1",
      title: "Profile Completion",
      description: "Complete your profile information",
      completed: true,
      progress: 100
    },
    {
      id: "2",
      title: "Aptitude Assessment",
      description: "Take the comprehensive aptitude quiz",
      completed: true,
      progress: 100
    },
    {
      id: "3",
      title: "College Exploration",
      description: "Explore at least 5 colleges in your area",
      completed: false,
      progress: 60
    },
    {
      id: "4",
      title: "Career Path Planning",
      description: "Review detailed career mapping for your stream",
      completed: false,
      progress: 30
    }
  ];

  const notifications = [
    {
      id: "1",
      title: "JEE Main Registration",
      message: "Registration deadline approaching in 5 days",
      type: "urgent",
      time: "2 hours ago"
    },
    {
      id: "2",
      title: "New Scholarship Available",
      message: "Merit scholarship for science students now open",
      type: "info",
      time: "1 day ago"
    },
    {
      id: "3",
      title: "College Application Reminder",
      message: "Complete your IIT Delhi application",
      type: "reminder",
      time: "3 days ago"
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleElements(prev => new Set([...prev, entry.target.id]));
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" }
    );

    document.querySelectorAll("[data-fade-in]").forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const handleSaveProfile = () => {
    setUserProfile(editedProfile);
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditedProfile(userProfile);
    setIsEditing(false);
  };

  const toggleSaveRecommendation = (id: string) => {
    // In a real app, this would make an API call
    console.log(`Toggle save for recommendation ${id}`);
  };

  const getRecommendationIcon = (type: string) => {
    switch (type) {
      case 'course': return <BookOpen className="h-4 w-4" />;
      case 'college': return <MapPin className="h-4 w-4" />;
      case 'career': return <Route className="h-4 w-4" />;
      default: return <Star className="h-4 w-4" />;
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'urgent': return "🚨";
      case 'info': return "ℹ️";
      case 'reminder': return "⏰";
      default: return "📢";
    }
  };

  const overallProgress = Math.round(achievements.reduce((acc, achievement) => acc + achievement.progress, 0) / achievements.length);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pt-20">
      <div className="container mx-auto px-6 py-12">
        {/* Hero Header with Personalized Avatar */}
        <div 
          id="profile-hero"
          data-fade-in
          className={`mb-12 transition-all duration-600 ${
            visibleElements.has("profile-hero") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <Card className="bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-xl">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-center space-y-6 md:space-y-0 md:space-x-8">
                <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <span className="text-4xl">👩‍🎓</span>
                </div>
                <div className="text-center md:text-left flex-1">
                  <h1 className="text-4xl font-bold mb-2">
                    Welcome back, {userProfile.name}!
                  </h1>
                  <p className="text-xl opacity-90 mb-4">
                    Let's continue building your educational journey
                  </p>
                  <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-4 w-4" />
                      <span className="text-sm">{overallProgress}% Profile Complete</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Star className="h-4 w-4" />
                      <span className="text-sm">Science Stream Match</span>
                    </div>
                  </div>
                </div>
                <Button 
                  variant="secondary"
                  onClick={() => setIsEditing(true)}
                  className="bg-white/20 hover:bg-white/30 text-white border-white/30"
                  data-testid="button-edit-profile"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="dashboard" data-testid="tab-dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="recommendations" data-testid="tab-recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="notifications" data-testid="tab-notifications">Notifications</TabsTrigger>
            <TabsTrigger value="settings" data-testid="tab-settings">Settings</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* User Profile Card */}
              <Card className="lg:col-span-1">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <User className="h-5 w-5" />
                    <span>Profile Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {isEditing ? (
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={editedProfile.name}
                          onChange={(e) => setEditedProfile(prev => ({ ...prev, name: e.target.value }))}
                          data-testid="input-edit-name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="age">Age</Label>
                        <Input
                          id="age"
                          value={editedProfile.age}
                          onChange={(e) => setEditedProfile(prev => ({ ...prev, age: e.target.value }))}
                          data-testid="input-edit-age"
                        />
                      </div>
                      <div>
                        <Label htmlFor="class">Current Class</Label>
                        <Select 
                          value={editedProfile.class} 
                          onValueChange={(value) => setEditedProfile(prev => ({ ...prev, class: value }))}
                        >
                          <SelectTrigger data-testid="select-edit-class">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="10th">10th Standard</SelectItem>
                            <SelectItem value="11th Science">11th Science</SelectItem>
                            <SelectItem value="11th Commerce">11th Commerce</SelectItem>
                            <SelectItem value="11th Arts">11th Arts</SelectItem>
                            <SelectItem value="12th Science">12th Science</SelectItem>
                            <SelectItem value="12th Commerce">12th Commerce</SelectItem>
                            <SelectItem value="12th Arts">12th Arts</SelectItem>
                            <SelectItem value="Graduate">Graduate</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="location">Location</Label>
                        <Input
                          id="location"
                          value={editedProfile.location}
                          onChange={(e) => setEditedProfile(prev => ({ ...prev, location: e.target.value }))}
                          data-testid="input-edit-location"
                        />
                      </div>
                      <div className="flex space-x-2">
                        <Button onClick={handleSaveProfile} size="sm" data-testid="button-save-profile">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Save
                        </Button>
                        <Button onClick={handleCancelEdit} variant="outline" size="sm" data-testid="button-cancel-edit">
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Name:</span>
                        <span className="font-medium">{userProfile.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Age:</span>
                        <span className="font-medium">{userProfile.age} years</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Class:</span>
                        <span className="font-medium">{userProfile.class}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Location:</span>
                        <span className="font-medium">{userProfile.location}</span>
                      </div>
                      <Separator />
                      <div>
                        <span className="text-sm text-muted-foreground">Interests:</span>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {userProfile.interests.map(interest => (
                            <Badge key={interest} variant="secondary" className="text-xs">
                              {interest}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Progress Tracker */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5" />
                    <span>Your Progress</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-lg font-semibold">Overall Progress</span>
                      <span className="text-2xl font-bold text-primary">{overallProgress}%</span>
                    </div>
                    <Progress value={overallProgress} className="h-3" />
                    <p className="text-sm text-muted-foreground mt-2">
                      You're {overallProgress}% on your way to your educational goals! 🎯
                    </p>
                  </div>

                  <div className="space-y-4">
                    {achievements.map((achievement) => (
                      <div key={achievement.id} className="flex items-center space-x-4 p-4 bg-muted/50 rounded-xl">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          achievement.completed ? 'bg-green-500' : 'bg-gray-300'
                        }`}>
                          {achievement.completed ? (
                            <CheckCircle className="h-5 w-5 text-white" />
                          ) : (
                            <span className="text-white font-bold text-sm">{Math.round(achievement.progress)}%</span>
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="font-semibold">{achievement.title}</h4>
                            {!achievement.completed && (
                              <Badge variant="outline" className="text-xs">
                                {achievement.progress}%
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{achievement.description}</p>
                          {!achievement.completed && (
                            <Progress value={achievement.progress} className="h-2 mt-2" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Recommendations Tab */}
          <TabsContent value="recommendations" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Personalized Recommendations</CardTitle>
                <p className="text-muted-foreground">Based on your profile and quiz results</p>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recommendations.map((rec) => {
                    const Icon = getRecommendationIcon(rec.type);
                    return (
                      <Card key={rec.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-center space-x-2">
                              {Icon}
                              <Badge 
                                variant="outline" 
                                className="text-xs capitalize"
                              >
                                {rec.type}
                              </Badge>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => toggleSaveRecommendation(rec.id)}
                              className="h-8 w-8"
                              data-testid={`button-save-${rec.id}`}
                            >
                              <Bookmark 
                                className={`h-4 w-4 ${rec.saved ? 'fill-current text-primary' : ''}`} 
                              />
                            </Button>
                          </div>
                          
                          <h4 className="font-semibold mb-2">{rec.title}</h4>
                          <p className="text-sm text-muted-foreground mb-3">{rec.description}</p>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-1">
                              <Star className="h-4 w-4 text-yellow-500 fill-current" />
                              <span className="text-sm font-medium">{rec.match}% match</span>
                            </div>
                            <Button size="sm" variant="ghost" className="text-xs">
                              Learn More →
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Bell className="h-5 w-5" />
                  <span>Notification Center</span>
                </CardTitle>
                <p className="text-muted-foreground">Stay updated with important deadlines and opportunities</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notifications.map((notification) => (
                    <div 
                      key={notification.id}
                      className="flex items-start space-x-4 p-4 border rounded-xl hover:bg-muted/50 transition-colors"
                    >
                      <div className="text-2xl">{getNotificationIcon(notification.type)}</div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-semibold">{notification.title}</h4>
                          <span className="text-xs text-muted-foreground">{notification.time}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{notification.message}</p>
                      </div>
                      <Button variant="ghost" size="sm" data-testid={`button-notification-${notification.id}`}>
                        View
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Notification Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Bell className="h-5 w-5" />
                    <span>Notification Preferences</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Push Notifications</div>
                      <div className="text-sm text-muted-foreground">Receive alerts for deadlines and updates</div>
                    </div>
                    <Switch 
                      checked={notificationsEnabled}
                      onCheckedChange={setNotificationsEnabled}
                      data-testid="switch-notifications"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Email Alerts</div>
                      <div className="text-sm text-muted-foreground">Get important updates via email</div>
                    </div>
                    <Switch 
                      checked={emailAlerts}
                      onCheckedChange={setEmailAlerts}
                      data-testid="switch-email-alerts"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">SMS Alerts</div>
                      <div className="text-sm text-muted-foreground">Urgent notifications via SMS</div>
                    </div>
                    <Switch 
                      checked={smsAlerts}
                      onCheckedChange={setSmsAlerts}
                      data-testid="switch-sms-alerts"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Accessibility Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Settings className="h-5 w-5" />
                    <span>Accessibility & Display</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label htmlFor="language">Language Preference</Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className="mt-2" data-testid="select-language">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="English">English</SelectItem>
                        <SelectItem value="Hindi">हिंदी (Hindi)</SelectItem>
                        <SelectItem value="Bengali">বাংলা (Bengali)</SelectItem>
                        <SelectItem value="Tamil">தமிழ் (Tamil)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium flex items-center space-x-2">
                        {reducedMotion ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                        <span>Reduced Motion</span>
                      </div>
                      <div className="text-sm text-muted-foreground">Minimize animations and transitions</div>
                    </div>
                    <Switch 
                      checked={reducedMotion}
                      onCheckedChange={setReducedMotion}
                      data-testid="switch-reduced-motion"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium flex items-center space-x-2">
                        {highContrast ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                        <span>High Contrast</span>
                      </div>
                      <div className="text-sm text-muted-foreground">Enhance text and element visibility</div>
                    </div>
                    <Switch 
                      checked={highContrast}
                      onCheckedChange={setHighContrast}
                      data-testid="switch-high-contrast"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Saved Items */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Bookmark className="h-5 w-5" />
                  <span>Saved Items</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {recommendations.filter(rec => rec.saved).map((rec) => {
                    const Icon = getRecommendationIcon(rec.type);
                    return (
                      <Card key={rec.id} className="border hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-2 mb-2">
                            {Icon}
                            <Badge variant="outline" className="text-xs capitalize">
                              {rec.type}
                            </Badge>
                          </div>
                          <h4 className="font-semibold text-sm mb-1">{rec.title}</h4>
                          <p className="text-xs text-muted-foreground line-clamp-2">{rec.description}</p>
                          <div className="flex items-center justify-between mt-3">
                            <div className="flex items-center space-x-1">
                              <Star className="h-3 w-3 text-yellow-500 fill-current" />
                              <span className="text-xs">{rec.match}%</span>
                            </div>
                            <Button variant="ghost" size="sm" className="text-xs h-6 px-2">
                              View
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications Tab Content */}
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Recent Notifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notifications.map((notification) => (
                    <div 
                      key={notification.id}
                      className={`p-4 rounded-xl border-l-4 ${
                        notification.type === 'urgent' ? 'border-red-500 bg-red-50' :
                        notification.type === 'info' ? 'border-blue-500 bg-blue-50' :
                        'border-orange-500 bg-orange-50'
                      }`}
                      data-testid={`notification-${notification.id}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{notification.title}</h4>
                        <span className="text-xs text-muted-foreground">{notification.time}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{notification.message}</p>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline" className="text-xs">
                          Mark as Read
                        </Button>
                        <Button size="sm" className="text-xs">
                          Take Action
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab Content */}
          <TabsContent value="settings">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Account Settings */}
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your.email@example.com"
                      className="mt-2"
                      data-testid="input-email"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+91 9876543210"
                      className="mt-2"
                      data-testid="input-phone"
                    />
                  </div>
                  <Button className="w-full" data-testid="button-update-account">
                    Update Account
                  </Button>
                </CardContent>
              </Card>

              {/* Privacy Settings */}
              <Card>
                <CardHeader>
                  <CardTitle>Privacy & Data</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Location Sharing</div>
                      <div className="text-sm text-muted-foreground">Allow location-based college recommendations</div>
                    </div>
                    <Switch defaultChecked data-testid="switch-location-sharing" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Analytics</div>
                      <div className="text-sm text-muted-foreground">Help improve our recommendations</div>
                    </div>
                    <Switch defaultChecked data-testid="switch-analytics" />
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full" data-testid="button-download-data">
                      Download My Data
                    </Button>
                    <Button variant="outline" className="w-full" data-testid="button-delete-account">
                      Delete Account
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Quick Actions */}
        <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="p-6">
            <h4 className="font-semibold mb-4 text-center">🚀 Quick Actions</h4>
            <div className="grid md:grid-cols-3 gap-4">
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                <BookOpen className="h-6 w-6 text-blue-600" />
                <span className="text-sm font-medium">Retake Quiz</span>
                <span className="text-xs text-muted-foreground">Update your assessment</span>
              </Button>
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                <MapPin className="h-6 w-6 text-green-600" />
                <span className="text-sm font-medium">Explore Colleges</span>
                <span className="text-xs text-muted-foreground">Find more options</span>
              </Button>
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                <Calendar className="h-6 w-6 text-orange-600" />
                <span className="text-sm font-medium">Check Deadlines</span>
                <span className="text-xs text-muted-foreground">View upcoming events</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
