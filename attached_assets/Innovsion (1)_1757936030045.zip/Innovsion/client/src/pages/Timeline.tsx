import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, AlertCircle, CheckCircle, Bell } from "lucide-react";
import { useState } from "react";
import type { Timeline as TimelineType } from "@shared/schema";

export default function Timeline() {
  const [selectedType, setSelectedType] = useState<string>("all");

  const { data: timelines, isLoading } = useQuery<TimelineType[]>({
    queryKey: ["/api/timelines", selectedType],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedType && selectedType !== "all") params.append("type", selectedType);
      
      const response = await fetch(`/api/timelines?${params}`);
      if (!response.ok) throw new Error("Failed to fetch timelines");
      return response.json();
    },
  });

  const getTimelineIcon = (type: string) => {
    switch (type) {
      case 'exam':
        return CheckCircle;
      case 'admission':
        return Calendar;
      case 'scholarship':
        return Bell;
      default:
        return Clock;
    }
  };

  const getTimelineColor = (type: string) => {
    switch (type) {
      case 'exam':
        return 'from-blue-500 to-blue-600';
      case 'admission':
        return 'from-green-500 to-green-600';
      case 'scholarship':
        return 'from-orange-500 to-orange-600';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const getBadgeVariant = (deadline: Date | string) => {
    const deadlineDate = new Date(deadline);
    const now = new Date();
    const daysUntil = Math.ceil((deadlineDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntil < 0) return { variant: "secondary" as const, text: "Expired", color: "bg-gray-100 text-gray-800" };
    if (daysUntil <= 7) return { variant: "destructive" as const, text: "Urgent", color: "bg-red-100 text-red-800" };
    if (daysUntil <= 30) return { variant: "secondary" as const, text: "Coming Soon", color: "bg-orange-100 text-orange-800" };
    return { variant: "outline" as const, text: "Open", color: "bg-blue-100 text-blue-800" };
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 pt-20">
      <div className="container mx-auto px-6 py-12">
        <div className="text-center mb-16">
          <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Calendar className="text-white text-2xl" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Important Deadlines</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Never miss crucial dates for your educational journey. Stay updated with admissions, scholarships, and exam deadlines.
          </p>
        </div>

        {/* Filter Section */}
        <Card className="mb-8 shadow-lg">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row gap-4 items-center">
              <div className="flex-1">
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="w-full sm:w-64" data-testid="select-timeline-type">
                    <SelectValue placeholder="All Event Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Event Types</SelectItem>
                    <SelectItem value="exam">Exams</SelectItem>
                    <SelectItem value="admission">Admissions</SelectItem>
                    <SelectItem value="scholarship">Scholarships</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span>Urgent</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                  <span>Coming Soon</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span>Open</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Timeline Section */}
        {isLoading ? (
          <div className="space-y-6">
            {[...Array(5)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-6">
                    <div className="w-16 h-16 bg-gray-200 rounded-full"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded mb-4"></div>
                      <div className="flex space-x-4">
                        <div className="h-8 w-24 bg-gray-200 rounded"></div>
                        <div className="h-8 w-20 bg-gray-200 rounded"></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-6">
            {/* Timeline Line */}
            <div className="relative">
              <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary to-accent hidden lg:block"></div>
              
              {timelines?.map((timeline, index) => {
                const badgeInfo = getBadgeVariant(timeline.deadline);
                const timelineColor = getTimelineColor(timeline.type);
                const IconComponent = getTimelineIcon(timeline.type);
                
                return (
                  <Card 
                    key={timeline.id} 
                    className="hover:shadow-lg transition-shadow duration-300"
                    data-testid={`timeline-item-${timeline.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-6">
                        <div className={`w-16 h-16 bg-gradient-to-br ${timelineColor} rounded-full flex items-center justify-center shadow-lg z-10 relative`}>
                          <IconComponent className="h-5 w-5 text-white" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                            <h3 className="text-xl font-bold">{timeline.title}</h3>
                            <Badge className={badgeInfo.color}>
                              {badgeInfo.text}
                            </Badge>
                          </div>
                          
                          <p className="text-muted-foreground mb-4">
                            {String(timeline.description || '')}
                          </p>
                          
                          <div className="flex items-center justify-between flex-wrap gap-4">
                            <div className="flex items-center space-x-4">
                              <span className="text-sm text-muted-foreground flex items-center">
                                <Clock className="h-4 w-4 mr-1" />
                                Deadline: {formatDate(timeline.deadline)}
                              </span>
                              
                              {timeline.streams && Array.isArray(timeline.streams) && (timeline.streams as string[]).length > 0 && (
                                <div className="flex gap-1 flex-wrap">
                                  {(timeline.streams as string[]).slice(0, 2).map((stream: string, index: number) => (
                                    <Badge key={`${stream}-${index}`} variant="outline" className="text-xs">
                                      {String(stream)}
                                    </Badge>
                                  ))}
                                  {(timeline.streams as string[]).length > 2 && (
                                    <Badge variant="outline" className="text-xs">
                                      +{(timeline.streams as string[]).length - 2}
                                    </Badge>
                                  )}
                                </div>
                              )}
                            </div>
                            
                            <div className="flex space-x-2">
                              <Button 
                                size="sm" 
                                variant="ghost"
                                data-testid={`button-reminder-${timeline.title.toLowerCase().replace(/\s+/g, '-')}`}
                              >
                                <Bell className="h-4 w-4 mr-1" />
                                Set Reminder
                              </Button>
                              
                              {getBadgeVariant(timeline.deadline).text !== "Expired" && (
                                <Button 
                                  size="sm"
                                  data-testid={`button-action-${timeline.title.toLowerCase().replace(/\s+/g, '-')}`}
                                >
                                  {timeline.type === 'exam' ? 'Register Now' : 
                                   timeline.type === 'admission' ? 'Apply Now' : 
                                   'View Details'}
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {timelines?.length === 0 && !isLoading && (
          <Card className="text-center p-12">
            <CardContent>
              <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No upcoming events</h3>
              <p className="text-muted-foreground mb-4">
                {selectedType 
                  ? `No ${selectedType} events found. Try selecting a different category.`
                  : "There are no upcoming deadlines at the moment. Check back later for updates."
                }
              </p>
              <Button variant="outline" onClick={() => setSelectedType("all")}>
                Show All Events
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Quick Actions */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <h4 className="font-semibold mb-4 text-center">📅 Stay Organized</h4>
            <div className="grid md:grid-cols-3 gap-4 text-sm">
              <div className="text-center">
                <Bell className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="font-medium">Enable Notifications</div>
                <div className="text-muted-foreground">Get alerts before deadlines</div>
              </div>
              <div className="text-center">
                <Calendar className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <div className="font-medium">Sync to Calendar</div>
                <div className="text-muted-foreground">Add events to your calendar</div>
              </div>
              <div className="text-center">
                <CheckCircle className="h-8 w-8 text-orange-600 mx-auto mb-2" />
                <div className="font-medium">Track Progress</div>
                <div className="text-muted-foreground">Mark completed applications</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
